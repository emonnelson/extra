package com.r.diagnosticactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnQuickoverview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView title = (TextView) findViewById(R.id.txtTitle);
        TextView symptom = (TextView) findViewById(R.id.txtSymptom);
        TextView tOverview = (TextView) findViewById(R.id.tvOverview);
        TextView overView = (TextView) findViewById(R.id.txtOverview);
        TextView hCommon = (TextView) findViewById(R.id.tvCommon);
        TextView tHowCommon = (TextView) findViewById(R.id.txthowCommon);
        TextView symptomView = (TextView) findViewById(R.id.txtSymptomView);
        TextView tSymptoms = (TextView) findViewById(R.id.txtSymptoms);
        TextView tTreatments = (TextView) findViewById(R.id.txtTreatment);
        TextView treatments = (TextView) findViewById(R.id.tvTreatment);
        btnQuickoverview = (Button) findViewById(R.id.btnQuickoverview);
        btnQuickoverview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }

    public void openDialog() {
        DialogBox dialogBox = new DialogBox();
        dialogBox.show(getSupportFragmentManager(), "dialog Box");

    }
}